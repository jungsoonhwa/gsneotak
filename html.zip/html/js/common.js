$(function(){
	//본문 바로가기 버튼
	jQuery(".directBt").focusin(function(){
		jQuery(this).css("top", "0");
	}).focusout(function(){
		jQuery(this).css("top", "-100px");
	})
	
	




	//window 리사이징
	jQuery(window).resize(function(){
		//jQuery("#cBody").width(jQuery(window).width()-200);
		//container height
		jQuery(".container").css("min-height",jQuery(window).height()-100);
		jQuery(".rightCon").height(jQuery(window).height());
		jQuery(".popBg").height(jQuery("#cBody").height());
		jQuery(".footPopBg").height(jQuery("#footer").height());
		if(jQuery("#cBody").height() < jQuery(window).height()) {
			jQuery("#header").css('height', jQuery(window).height());
			jQuery(".gnbShadow").css('height',  jQuery(window).height());
		} else {
			jQuery("#header").css('height', jQuery("#cBody").height());
			jQuery(".gnbShadow").css('height',jQuery("#cBody").height());
		}

		//푸터영역 window height따라 가변적으로 움직임
		if(jQuery(document).height() <= 800) {
			jQuery("#footer").css("top","582px");
		}else if(jQuery(window).height() > 800){
			jQuery("#footer").removeAttr("style");
			jQuery("#footer").css("bottom","0");
		}
	});jQuery(window).resize();
})

$(window).load(function(){
	jQuery(window).resize();
})